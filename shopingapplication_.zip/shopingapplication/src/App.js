//App.js

import React, { useState } from 'react';
import './App.css';
import SearchComponent from './Components/SearchComponent';
import ShowCourseComponent from './Components/ShowCourseComponent';
import UserCartComponent from './Components/UserCartComponent';
import Tshirt from './Asserts/T-shirts.jpg'
import Bag from './Asserts/Bag.jpg'
import Hoodie from './Asserts/Hoodies.png'
import Iphone from './Asserts/Iphone.jpg'
import Shoes from './Asserts/Shoes.jpg'
import Watch from './Asserts/Watch.jpg'
import Camera from './Asserts/Camera.jpg'
function App() {
	const [courses, setCourses] = useState([
		{ id: 1, 
		name: 'Camera', 
		price: 499, 
		image: Camera
		},
		{ id: 2, 
		name: 'Bag', 
		price: 699, 
		image: Bag
		},
    { id: 3, 
      name: 'IPhone', 
      price: 499, 
      image: Iphone
    },
		{ id: 4, 
		name: 'Shoes', 
		price: 799, 
		image: Shoes
		},
    { id: 5, 
      name: 'Watch', 
      price: 799, 
      image: Watch
    },
    { id: 6, 
      name: 'T-shirt', 
      price: 499, 
      image: Tshirt
      },
    { id: 7, 
      name: 'Hoodie', 
      price: 799, 
      image: Hoodie
    },
	]);

	const [cartCourses, setCartCourses] = useState([]);
	const [searchCourse, setSearchCourse] = useState('');

	const addCourseToCartFunction = (GFGcourse) => {
		const alreadyCourses = cartCourses
							.find(item => item.product.id === GFGcourse.id);
		if (alreadyCourses) {
			const latestCartUpdate = cartCourses.map(item =>
				item.product.id === GFGcourse.id ? { 
				...item, quantity: item.quantity + 1 } 
				: item
			);
			setCartCourses(latestCartUpdate);
		} else {
			setCartCourses([...cartCourses, {product: GFGcourse, quantity: 1}]);
		}
	};

	const deleteCourseFromCartFunction = (GFGCourse) => {
		const updatedCart = cartCourses
							.filter(item => item.product.id !== GFGCourse.id);
		setCartCourses(updatedCart);
	};

	const totalAmountCalculationFunction = () => {
		return cartCourses
			.reduce((total, item) => 
						total + item.product.price * item.quantity, 0);
	};

	const courseSearchUserFunction = (event) => {
		setSearchCourse(event.target.value);
	};

	const filterCourseFunction = courses.filter((course) =>
		course.name.toLowerCase().includes(searchCourse.toLowerCase())
	);

	return (
		<div className="App">
			<SearchComponent searchCourse={searchCourse} 
							courseSearchUserFunction=
								{courseSearchUserFunction} />
			<main className="App-main">
				<ShowCourseComponent
					courses={courses}
					filterCourseFunction={filterCourseFunction}
					addCourseToCartFunction={addCourseToCartFunction}
				/>

				<UserCartComponent
					cartCourses={cartCourses}
					deleteCourseFromCartFunction={deleteCourseFromCartFunction}
					totalAmountCalculationFunction={
						totalAmountCalculationFunction
					}
					setCartCourses={setCartCourses}
          
				/>
			</main>
              {/* <Payment
          totalAmountCalculationFunction={
						totalAmountCalculationFunction
					}
        /> */}
		</div>
	);
}

export default App;
