import React, { useState } from "react";
import Register from "./Register";
import './Login.css'
import App from "./App";
import { useHistory } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.css';

function Login() {
  const [loginDetails, setLoginDetails] = useState({
    email: "",
    password: "",
    GoToSignUpPage: false,
    LoginSuccess:false
  });

  const handleMoveToSignUpPage = (e) => {
    return setLoginDetails({ ...loginDetails, GoToSignUpPage: true });
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const { email, password } = loginDetails;
    if (!email || !password) {
      alert("Enter Email or Password");
      return;
    }
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const existingUser = users.find(
      (user) => user.email === email && user.password === password
    );
    if (!existingUser) {
      alert("Invalid Password or Email");
      return;
    }
    alert("Login successful");
    localStorage.setItem("loggedInUser", JSON.stringify(existingUser));
    setLoginDetails({...loginDetails,LoginSuccess:true})
    
  };

  if (loginDetails.GoToSignUpPage) {
    return <Register />;
  }
  if(loginDetails.LoginSuccess){
    return <App/>
  }

  return (
    <div>
      {!loginDetails.LoginSuccess &&(
        <>
          <div className="wrapper">
        <div className="title">Login Form</div>
        <form onSubmit={handleLogin}>
          <div className="field">
            <input
              type="email"
              value={loginDetails.email}
              onChange={(e) =>
                setLoginDetails({ ...loginDetails, email: e.target.value })
              }
              required
            />
            <label>Email Address</label>
          </div>
          <div className="field">
            <input
              type="password"
              value={loginDetails.password}
              onChange={(e) =>
                setLoginDetails({ ...loginDetails, password: e.target.value })
              }
              required
            />
            <label>Password</label>
          </div>
          <div className="field">
            <input type="submit" value="Login" />
          </div>
        </form>
      </div>
      <div>
        <form align="center" onSubmit={handleMoveToSignUpPage}>
          <div align="center" className="field">
            <label>New Users.....!</label>
            {/* <input
              style={{ textAlign: "center" }}
              type="submit"
              id="ip2"
              value="SignUp"
            /> */}
            <button type="submit" class="btn btn-primary" text-align='center'>Register</button>
          </div>
        </form>
      </div>
        </>
      )}
      
    </div>
  );
}

export default Login;
