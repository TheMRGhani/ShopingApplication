import React from "react";
//import App from "./App";
import { Component } from "react";
import './Register.css';
import Login from "./Login";
class Register extends Component{
constructor(props){
    super(props);
this.state={
    username:"",
    email:"",
    password:"",
    confirmpassword:"",
    gender:""
}
}
handleSubmit=(e)=>{
    e.preventDefault();
const {username,email,password,confirmpassword}=this.state;
if(!email){
    alert('Email is required')
} else if(!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email)){
alert("Email is Invalid")
}
if(!username){
    alert("Enter User Name")
    return
}
if(!password){
    alert("Enter Password")
    return
}else if(password.length<6 || !/^[a-zA-Z0-9!@#$%^&*]{6,16}$/.test(password)){
    alert("Password must have 6 charectors,Symbol and Upper case letter")
    return
}
if(password !==confirmpassword){
    alert("Password not matched")
    return
}
const users =JSON.parse(localStorage.getItem('users'))||[];
const existingUser=users.find((user)=>user.email===email);
if(existingUser){
    alert("User already Exist with this email")
    return;
}
const newUser={
    username,
    email,
    password,
};
users.push(newUser);
localStorage.setItem("users",JSON.stringify(users))
alert("Registration Successful")
return <Login/>
}
render(){
    const {username,email,password,confirmpassword,gender}=this.state
    return(
        <div class="container">
    <div class="title">Registration</div>
    <div class="content">
      <form  onSubmit={this.handleSubmit}>
        <div class="user-details">
          
          <div class="input-box">
            <span class="details">Username</span>
            <input type="text" value={username} placeholder="Enter your username" onChange={(e)=>this.setState({username:e.target.value})} required/>
            
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" value={email} onChange={(e)=>this.setState({email:e.target.value})} placeholder="Enter your email" required/>
            
          </div>
    
          <div class="input-box">
            <span class="details">Password</span>
            <input type="text" value={password} placeholder="Enter your password" onChange={(e)=>this.setState({password:e.target.value})} required/>
            
          </div>
          <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="text" value={confirmpassword} placeholder="Confirm your password" onChange={(e)=>this.setState({confirmpassword:e.target.value})} required/>
            
          </div>
        </div>
        <div class="gender-details">
          <label>Gender:</label>
          <select value={gender} onChange={(e)=>this.setState({gender:e.target.value})}>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Others">Others</option>


          </select>
        </div>
        <div class="button">
          <input type="submit" value="Register"/>
        </div>
      </form>
    </div>
    <div>
        <form >
            <input id="ip2" type="Submit" value="Back"/>
        </form>
    </div>
  </div>
    )
}
}
export default Register