import App from "./App";
import Login from "./Login";
import React, { Component } from "react";
class Home extends Component{
    state={
        loggedInUser:JSON.parse(localStorage.getItem("loggedInUser")),
    };
    render(){
        return(
            <div>
                <h1 align="center">Welcom To Cognizant</h1>
            </div>
        );
    }
}
export default Home